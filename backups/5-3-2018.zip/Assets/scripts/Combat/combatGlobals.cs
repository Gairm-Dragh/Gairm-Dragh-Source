﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class combatGlobals : MonoBehaviour {
    //all the players
    public List<player> players = new List<player>();

    //the teams
    public List<player> team1 = new List<player>();
    public List<player> team2 = new List<player>();
}
