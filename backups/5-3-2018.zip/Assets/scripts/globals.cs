﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class globals{
    public static int players = 0; //The number of players in the game
}
